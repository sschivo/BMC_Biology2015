Model.cys is the Cytoscape session file with the complete model from Section 3.2. You can open it in Cytoscape with File --> Open.
The .csv files contain the normalized series for some of the experimental data taken from [1]. You can add them to a simulation graph with the graph right-click menu "Add data from CSV" (see ANIMO's User Manual in Suppl. Section 2.1.1).
Initial activity levels and interaction parameters can be changed by the right-clicking on the corresponding nodes and edges and choosing "[ANIMO] Edit reactant/reaction...". For more detail about this, please consult ANIMO's User Manual in Supplementary Section 2.


[1] S. Gaudet, K. A. Janes, J. G. Albeck, E. A. Pace, D. A. Lauffenburger, P. K. Sorger, A compendium of signals and responses triggered by prodeath and prosurvival cytokines.  Mol. Cell Proteomics 4, 1569-1590 (2005)
